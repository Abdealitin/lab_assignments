package com.yash.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class VerifyUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String s1=request.getParameter("username");
        String s2=request.getParameter("pass");
        //String s3=request.getParameter("utype");
        
		if(s1.equals("admin") && s2.equals("admin")){
            response.sendRedirect("adminpage.html");
         }else{
             out.println("Invalid Admin Account");
             out.println("<a href=index.html>Try-Again</a>");
         }
	}


}
