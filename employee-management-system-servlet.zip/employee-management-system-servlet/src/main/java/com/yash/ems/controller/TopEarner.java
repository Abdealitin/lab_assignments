package com.yash.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TopEarner
 */
public class TopEarner extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		 out.println("<html>"
	        		+ "<head><title>Employee Information | EMS</title>"
	        		+ "<link\r\n"
	        		+ "	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\"\r\n"
	        		+ "	rel=\"stylesheet\"\r\n"
	        		+ "	integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\"\r\n"
	        		+ "	crossorigin=\"anonymous\">"
	        		+ "<style>\r\n"
	        		+ ".center {\r\n"
	        		+ "	margin: auto;\r\n"
	        		+ "	width: 50%;\r\n"
	        		+ "	border: 3px solid #73AD21;\r\n"
	        		+ "	padding: 10px;\r\n"
	        		+ "}\r\n"
	        		+ "</style>\r\n"
	        		+ "</head>"
	        		+ "<body>");
	        out.println("<h1 align='center'><centre>Top earner of the Organization</center</h1><hr><br>");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "root");  
            String sql = "select * from employee1 where salary = (select max(salary) from employee1)";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            out.println("<div class='center'><ul class=\"list-group\">\r\n"
            		+ "  <li class=\"list-group-item\">Employee ID :- "+rs.getInt(1)+"</li>\r\n"
            		+ "  <li class=\"list-group-item\">Employee Name :- "+rs.getString(2)+"</li>\r\n"
            		+ "  <li class=\"list-group-item\">Employee Designation :- "+rs.getString(3)+"</li>\r\n"
            		+ "  <li class=\"list-group-item active\">Employee Salary :- "+rs.getDouble(4)+"</li>\r\n"
            		+ "  <li class=\"list-group-item\">Employee Department :- "+rs.getString(5)+"</li>\r\n"
            		+ "</ul></div>");
            out.println("<br><h5 align='center'><a href=adminpage.html>Back-To-Dashbord</a></h5>");  
            out.println("</body></html>");  
            con.close();  
            
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
