package com.yash.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class GetEmployees
 */
@WebServlet("/GetEmployees")
public class GetEmployees extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html");  
        out.println("<html>"
        		+ "<head><title>Employees List | EMS</title>"
        		+ "<style>\r\n"
        		+ ".center {\r\n"
        		+ "	margin: auto;\r\n"
        		+ "	width: 25%;\r\n"
        		+ "	border: 3px solid #73AD21;\r\n"
        		+ "	padding: 10px;\r\n"
        		+ "}\r\n"
        		+ "</style>\r\n"
        		+ "</head>"
        		+ "<body>");
        out.println("<h1 align='center'><centre>Employees List</center</h1><hr><br>");
        try 
        {  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "root");  
              
            Statement stmt = (Statement) con.createStatement();  
            ResultSet rs = stmt.executeQuery("select * from employee1");  
            out.println("<div class = 'center'><table border=1 width=50% height=50%>");  
            out.println("<tr><th>Employee Id</th><th>Employee Name</th><th>Designation</th><th>Salary</th><th>Department</th><tr>");  
            while (rs.next()) 
            {     
                out.println("<tr><td>" + rs.getInt(1) + "</td><td>" + rs.getString(2) + "</td><td>" + rs.getString(3) + "</td><td>" + rs.getDouble(4)+"</td><td>" + rs.getString(5)+"</td></tr>");   
            }  
            out.println("</table></div>"
            		+ "<br><h5 align='center'><a href=adminpage.html>Back-To-Dashbord</a></h5>");  
            out.println("</body></html>");  
            con.close();  
           }  
            catch (Exception e) 
           {  
           e.printStackTrace();  
        }  
	}



}
