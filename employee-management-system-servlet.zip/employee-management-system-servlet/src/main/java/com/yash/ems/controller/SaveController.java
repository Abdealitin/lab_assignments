package com.yash.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.ems.util.DataUtility;

/**
 * Servlet implementation class SaveController
 */
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String empid =request.getParameter("empid");
		String name = request.getParameter("name");
		String desg = request.getParameter("desg");
		String sal = request.getParameter("sal");
		String dept = request.getParameter("dept");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");  
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "root");
			String sql = "insert into employee1 values(?,?,?,?,?)";
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, Integer.parseInt(empid));
			st.setString(2, name);
			st.setString(3, desg);
			st.setDouble(4, Double.parseDouble(sal));
			st.setString(5, dept);
			
			st.executeUpdate();
			out.println("<html>");
	        out.println("<body>");
	        out.println("<h4>Employee Added Successfully</h4>");
	        out.println("<h5><a href=adminpage.html>Dashbord</a></h5>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
 	}

}
